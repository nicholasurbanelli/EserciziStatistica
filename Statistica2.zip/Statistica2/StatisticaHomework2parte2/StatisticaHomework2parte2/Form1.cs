﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StatisticaHomework2parte2
{
    public partial class Form1 : Form
    {
        String Path = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Title = "Open File",
                Filter = "csv files (*.csv)|*.csv",
                CheckFileExists = true,
                CheckPathExists = true,
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                String fileName = System.IO.Path.GetFileName(ofd.FileName);
                MessageBox.Show(fileName + " dataset loaded");
                Path = ofd.FileName;
            }

            TextFieldParser parser = new TextFieldParser(Path);
            parser.TextFieldType = FieldType.Delimited;
            parser.SetDelimiters(",");
            while (!parser.EndOfData)
            {
                string riga = parser.ReadLine();
                this.richTextBox1.AppendText(riga + "\n");
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        string[] colori = { "brown", "blue", "green", "black" };
        int[] amount = { 0, 0, 0, 0 };

        private void button2_Click(object sender, EventArgs e)
        {
            this.richTextBox2.AppendText("Results \n");
            using (TextFieldParser parser = new TextFieldParser(Path))
            {
                parser.TextFieldType = FieldType.Delimited;
                parser.SetDelimiters(",");
                string[] attribute = parser.ReadFields();
                int indice = 0;
                for (int i = 0; i<attribute.Length; i++)
                {
                    if (attribute[i] == "Eye_color")
                    {
                        indice = i;
                    }
                }
                while (!parser.EndOfData)
                {
                    string[] values = parser.ReadFields();
                    for (int i = 0; i < colori.Length; i++)
                    {
                        if (colori[i] == values[indice].ToLower())
                        {
                            amount[i]++;
                        }
                    }
                }
            }
            int total = 0;
            for (int i = 0; i < amount.Length; i++)
            {
                total = total + amount[i];
            }
            for (int i = 0; i < colori.Length; i++)
            {
                string color = colori[i];
                int number = amount[i];
                float x1 = number;
                float x2 = total;
                float x = x1 / x2;
                this.richTextBox2.AppendText(color + ": " + number.ToString() + "  " + "percentage frequency: " + x * 100 + "%" + "\n");
            }

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
